-- params: table-name
PRAGMA index_list(`~a`)
