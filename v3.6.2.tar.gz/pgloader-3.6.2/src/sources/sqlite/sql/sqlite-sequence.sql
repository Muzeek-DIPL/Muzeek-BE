SELECT tbl_name
  FROM sqlite_master
 WHERE tbl_name = 'sqlite_sequence'
