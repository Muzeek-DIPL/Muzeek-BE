PRAGMA table_info(`~a`)
