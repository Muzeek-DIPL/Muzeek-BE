# Test data files.

Most of the files have been contributed by pgloader users in the context of
an issue where it was helpful to have a test case to reproduce and fix a
bug.

The following DBF test files come from the Open Source repository at
https://github.com/infused/dbf/tree/master/spec/fixtures
  
  - dbase_31.dbf
  - dbase_31_summary.txt
  - dbase_8b.dbf
  - dbase_8b.dbt
  - dbase_8b_summary.txt
