# pgloader tests for MySQL

The idea here is to create a MySQL database with a static known set of data
so that we may then compare the data against a PostgreSQL load done with
pgloader.

This is very much WIP at the moment, but at least it got started.
